ALWAYS BACKUP YOUR FILES!!!

DOES NOT WORK WITH DELTARUNE CHAPTER 2!!!

Heres how to add this mod to Deltarune.

Step 1.
Backup your files first in another folder, you can skip this step if its already done.

Step 2.
Copy the data.win file inside the Mod folder then delete the data.win file inside SURVEY_PROGRAM (Deltarune).
Then paste the data.win file you copied earlier into SURVEY_PROGRAM

Step 3.
Copy the lang_en.json file inside the Mod folder then delete the lang_en.json file inside the lang folder in SURVEY_PROGRAM (Deltarune).
Then paste the lang_en.json file inside the lang folder