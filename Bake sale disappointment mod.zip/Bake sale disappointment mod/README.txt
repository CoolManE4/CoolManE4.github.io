ALWAYS BACKUP YOUR FILES!!!

DOES NOT WORK WITH DELTARUNE CHAPTER 2!!!

Heres how to add this mod to Deltarune.

You will need to download DeltaPatcher lite.

Step 1.
Backup your files first in another folder, you can skip this step if its already done.

Step 2.
Open deltapatcher select the xdelta file patch it into SURVEY_PROGRAM data

Step 3.
Copy the lang_en.json file inside the Mod folder then delete the lang_en.json file inside the lang folder in SURVEY_PROGRAM (Deltarune).
Then paste the lang_en.json file inside the lang folder